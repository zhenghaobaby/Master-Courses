#include "TradePayment.h"

namespace minirisk {

const guid_t TradePayment::m_id = 0;
const std::string TradePayment::m_name = "Payment";

} // namespace minirisk





