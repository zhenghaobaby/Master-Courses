void test1()
{
}

void test2()
{
}

void test3()
{
}

int main()
{
    test1();
    test2();
    test3();
    return 0;
}

