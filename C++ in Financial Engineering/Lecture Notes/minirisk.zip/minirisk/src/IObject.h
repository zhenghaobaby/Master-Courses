#pragma once

namespace minirisk {

struct IObject
{
    virtual ~IObject() {};
};

} // namespace minirisk
